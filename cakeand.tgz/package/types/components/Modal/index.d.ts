export { ModalTitle } from './ModalTitle';
export type { ModalTitleProps } from './ModalTitle';
export { ModalIcon } from './ModalIcon';
export type { ModalIconProps, ModalIconType } from './ModalIcon';
export { ModalContent } from './ModalContent';
export type { ModalContentProps } from './ModalContent';
export { ModalFooter } from './ModalFooter';
export type { ModalFooterProps } from './ModalFooter';
export { Modal } from './Modal';
export type { ModalProps } from './Modal';
//# sourceMappingURL=index.d.ts.map